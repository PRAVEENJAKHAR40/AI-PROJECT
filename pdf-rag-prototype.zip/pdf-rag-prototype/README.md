
# PDF RAG Prototype

A minimal, production-ready prototype for an AI-powered PDF Q&A app (RAG) you can upload to GitHub.

**Features**
- Upload multiple PDFs
- Extract text with PyMuPDF
- Chunk text and generate embeddings with `sentence-transformers`
- Vector search with FAISS (persisted locally in `app/storage/`)
- Streamlit chat-style UI for asking questions
- Optional LLM answer generation via OpenAI (uses context from retrieval). If no API key is set, the app falls back to a concise extractive answer based on retrieved chunks.
- Clean project structure, tests, Dockerfile, and Makefile

> Built for the assignment requirements (last updated: 2025-08-24).

---

## Quickstart (Local)

```bash
# 1) Create and activate a virtual env (recommended)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) (Optional) Set your OpenAI API key for better answers
export OPENAI_API_KEY=sk-...   # Windows (Powershell): $Env:OPENAI_API_KEY="sk-..."

# 4) Run the app
streamlit run app/app.py
```

Open the URL that Streamlit prints (usually http://localhost:8501). Upload PDFs in the sidebar, then ask a question in the chat box.

---

## Project Structure

```
pdf-rag-prototype/
├─ app/
│  ├─ app.py               # Streamlit UI (upload + chat)
│  ├─ ingest.py            # PDF parsing, chunking, embedding, FAISS index build/update
│  ├─ utils.py             # Helpers (cleaning, chunking, OpenAI fallback, retrieval)
│  ├─ storage/             # Local persisted FAISS index + metadata (auto-created)
│  └─ sample_pdfs/
│     └─ sample.pdf        # Example PDF
├─ tests/
│  └─ test_chunking.py     # Simple unit tests for chunking
├─ requirements.txt
├─ Dockerfile
├─ Makefile
└─ README.md
```

---

## How it Works

1. **Upload & Ingest**  
   PDFs are parsed with PyMuPDF. Text is cleaned and chunked (size ~500 chars, overlap 50). Embeddings are generated with `sentence-transformers` (`all-MiniLM-L6-v2`). We add vectors to a FAISS index (cosine similarity via inner product on normalized vectors). Metadata (source path, page, chunk id) and raw text are saved alongside for retrieval.

2. **Query Answering (RAG)**  
   Your question is embedded, we do top-*k* vector search in FAISS, then build a context window. If an `OPENAI_API_KEY` is set, we call OpenAI (gpt-3.5 or newer if available). Otherwise, we synthesize a concise answer from retrieved chunks using a lightweight extractive strategy.

3. **Sources**  
   The UI shows the source filename and page numbers used to answer.

---

## Environment Variables

- `OPENAI_API_KEY` (optional): Enables LLM answer generation.
- `MODEL_NAME` (optional): SentenceTransformer model (default: `sentence-transformers/all-MiniLM-L6-v2`).
- `INDEX_DIR` (optional): Where to persist FAISS + metadata (default: `app/storage`).

---

## Docker

```bash
# Build
docker build -t pdf-rag .

# Run (expose Streamlit on port 8501)
docker run -it --rm -p 8501:8501 -e OPENAI_API_KEY=$OPENAI_API_KEY pdf-rag
```

---

## Testing

```bash
pytest -q
```

---

## Known Limitations

- Large PDFs will ingest, but memory usage scales with content size.
- The non-OpenAI fallback is extractive (no generative reasoning). For best results, set an API key.
- No authentication; do not expose this container directly to the internet without adding auth/rate limits.

---

## License

MIT
