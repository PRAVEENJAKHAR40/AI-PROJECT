
from app.utils import chunk_text

def test_chunking_basic():
    text = "abcdef" * 200  # 1200 chars
    chunks = chunk_text(text, chunk_size=500, overlap=50)
    assert len(chunks) >= 3
    assert all(len(c) <= 500 for c in chunks)
