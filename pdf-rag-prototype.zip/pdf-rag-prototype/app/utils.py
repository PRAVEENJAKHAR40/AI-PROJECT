
import os
import io
import json
import faiss
import numpy as np
from typing import List, Dict, Tuple
from sentence_transformers import SentenceTransformer
from sklearn.preprocessing import normalize
import fitz  # PyMuPDF

DEFAULT_MODEL = os.getenv("MODEL_NAME", "sentence-transformers/all-MiniLM-L6-v2")
INDEX_DIR = os.getenv("INDEX_DIR", "app/storage")
INDEX_PATH = os.path.join(INDEX_DIR, "faiss.index")
META_PATH = os.path.join(INDEX_DIR, "meta.jsonl")
TEXT_PATH = os.path.join(INDEX_DIR, "texts.jsonl")

def ensure_storage():
    os.makedirs(INDEX_DIR, exist_ok=True)

def load_encoder(model_name: str = DEFAULT_MODEL):
    return SentenceTransformer(model_name)

def _normalize(vectors: np.ndarray) -> np.ndarray:
    # cosine similarity via inner product on normalized vectors
    return normalize(vectors, norm="l2", axis=1)

def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    text = ' '.join(text.split())
    chunks = []
    i = 0
    while i < len(text):
        chunk = text[i:i+chunk_size]
        if not chunk:
            break
        chunks.append(chunk)
        i += max(1, chunk_size - overlap)
    return chunks

def parse_pdf(pdf_bytes: bytes) -> List[Tuple[int, str]]:
    # returns list of (page_number, text)
    doc = fitz.open(stream=io.BytesIO(pdf_bytes), filetype="pdf")
    pages = []
    for i, page in enumerate(doc):
        pages.append((i+1, page.get_text("text")))
    return pages

def build_or_load_index(encoder, dim: int = 384):
    ensure_storage()
    if os.path.exists(INDEX_PATH):
        index = faiss.read_index(INDEX_PATH)
    else:
        # inner product on normalized vectors
        index = faiss.IndexFlatIP(dim)
    return index

def persist_index(index, all_texts: List[str], all_metas: List[Dict]):
    faiss.write_index(index, INDEX_PATH)
    # append-style metadata store
    with open(META_PATH, "a", encoding="utf-8") as mf:
        for m in all_metas:
            mf.write(json.dumps(m, ensure_ascii=False) + "\n")
    with open(TEXT_PATH, "a", encoding="utf-8") as tf:
        for t in all_texts:
            tf.write(json.dumps({"text": t}, ensure_ascii=False) + "\n")

def read_metadata() -> Tuple[List[Dict], List[str]]:
    metas, texts = [], []
    if os.path.exists(META_PATH):
        with open(META_PATH, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    metas.append(json.loads(line))
    if os.path.exists(TEXT_PATH):
        with open(TEXT_PATH, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    texts.append(json.loads(line)["text"])
    return metas, texts

def embed_texts(encoder, texts: List[str]) -> np.ndarray:
    embeddings = encoder.encode(texts, convert_to_numpy=True, show_progress_bar=False)
    embeddings = _normalize(embeddings.astype("float32"))
    return embeddings

def add_to_index(index, embeddings: np.ndarray):
    index.add(embeddings)

def search(index, query_vec: np.ndarray, top_k: int = 5) -> Tuple[np.ndarray, np.ndarray]:
    D, I = index.search(query_vec, top_k)
    return D[0], I[0]

def get_top_contexts(I: np.ndarray, metas: List[Dict], texts: List[str]) -> List[Dict]:
    contexts = []
    for idx in I:
        if idx < 0:
            continue
        if idx < len(metas) and idx < len(texts):
            m = metas[idx]
            t = texts[idx]
            contexts.append({
                "text": t,
                "source": m.get("source", ""),
                "page": m.get("page", None),
                "chunk_id": m.get("chunk_id", None),
            })
    return contexts

def synthesize_answer(question: str, contexts: List[Dict], max_chars: int = 1000) -> str:
    # Lightweight extractive fallback: returns the most relevant snippets concatenated.
    joined = "\n\n".join([c["text"] for c in contexts])
    if len(joined) > max_chars:
        joined = joined[:max_chars] + "..."
    return f"Context-based answer (no LLM configured). Here are the most relevant excerpts:\n\n{joined}"

def call_openai_if_configured(question: str, contexts: List[Dict]) -> str:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        context_block = "\n\n".join([f"[p{c['page']}] {c['text']}" for c in contexts])
        prompt = (
            "You are a helpful assistant. Answer the user's question strictly using the provided context. "
            "Cite page numbers in square brackets when relevant. If the answer isn't in the context, say so.\n\n"
            f"Context:\n{context_block}\n\nQuestion: {question}"
        )
        resp = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role":"user","content":prompt}],
            temperature=0.2,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return None
