
import os
import streamlit as st
from typing import List
from .utils import (
    load_encoder, build_or_load_index, embed_texts, search, read_metadata,
    get_top_contexts, call_openai_if_configured, synthesize_answer, ensure_storage
)
from .ingest import ingest_many

st.set_page_config(page_title="PDF RAG Prototype", page_icon="📄", layout="wide")

st.title("📄 PDF RAG Prototype")

with st.sidebar:
    st.header("Upload PDFs")
    uploaded = st.file_uploader("Upload one or more PDF files", type=["pdf"], accept_multiple_files=True)
    if st.button("Ingest PDFs", type="primary") and uploaded:
        files = [u.getvalue() for u in uploaded]
        names = [u.name for u in uploaded]
        stats = ingest_many(files, names)
        st.success(f"Ingested {stats['pages']} pages into {stats['added_chunks']} chunks.")

    st.markdown("---")
    st.caption("Index storage path: `app/storage/`")
    if st.button("Clear Index"):
        import shutil
        storage = os.getenv("INDEX_DIR", "app/storage")
        if os.path.exists(storage):
            shutil.rmtree(storage)
        ensure_storage()
        st.success("Cleared index and metadata.")

# Chat/Q&A
st.subheader("Ask a question about your PDFs")
question = st.text_input("Your question", placeholder="e.g., What is the objective mentioned in the document?")

if st.button("Answer") and question.strip():
    encoder = load_encoder()
    index = build_or_load_index(encoder, dim=encoder.get_sentence_embedding_dimension())
    metas, texts = read_metadata()
    if len(metas) == 0 or index.ntotal == 0:
        st.warning("Please upload and ingest PDFs first.")
    else:
        query_vec = embed_texts(encoder, [question])
        D, I = index.search(query_vec, 5)
        contexts = get_top_contexts(I[0], metas, texts)

        with st.expander("Sources used"):
            for c in contexts:
                st.write(f"• **{c['source']}** — page {c['page']}, chunk {c['chunk_id']}")

        answer = call_openai_if_configured(question, contexts)
        if not answer:
            answer = synthesize_answer(question, contexts)
        st.markdown("### Answer")
        st.write(answer)

st.markdown("---")
st.caption("Tip: Set OPENAI_API_KEY for higher-quality answers.")
