
import os
from typing import List, Dict
from .utils import (
    load_encoder, build_or_load_index, embed_texts, add_to_index,
    persist_index, parse_pdf, chunk_text
)

def ingest_pdf_bytes(pdf_bytes: bytes, source_name: str) -> Dict:
    encoder = load_encoder()
    index = build_or_load_index(encoder, dim=encoder.get_sentence_embedding_dimension())
    pages = parse_pdf(pdf_bytes)
    texts, metas = [], []
    for page_num, page_text in pages:
        chunks = chunk_text(page_text)
        for j, chunk in enumerate(chunks):
            texts.append(chunk)
            metas.append({
                "source": source_name,
                "page": page_num,
                "chunk_id": j,
            })
    if texts:
        embs = embed_texts(encoder, texts)
        add_to_index(index, embs)
        persist_index(index, texts, metas)
    return {"added_chunks": len(texts), "pages": len(pages)}

def ingest_many(files: List[bytes], names: List[str]) -> Dict:
    total_chunks = 0
    total_pages = 0
    for b, n in zip(files, names):
        stats = ingest_pdf_bytes(b, n)
        total_chunks += stats["added_chunks"]
        total_pages += stats["pages"]
    return {"added_chunks": total_chunks, "pages": total_pages}
